require('./settings/settings')
const {
default: makeWASocket,
useMultiFileAuthState,
DisconnectReason,
generateForwardMessageContent,
generateWAMessageFromContent,
fetchLatestBaileysVersion,
downloadContentFromMessage,
makeInMemoryStore,
jidDecode,
proto,
Browsers
} = require('@whiskeysockets/baileys')
const axios = require('axios')
const chalk = require('chalk')
const fs = require('fs')
const FileType = require('file-type')
const nou = require('node-os-utils')
const os = require('os')
const path = require('path')
const readline = require('readline')
const PhoneNumber = require('awesome-phonenumber')
const {
imageToWebp,
imageToWebp3,
videoToWebp,
writeExifImg,
writeExifImgAV,
writeExifVid
} = require('./lib/exif')
const {
getBuffer,
sleep,
smsg
} = require('./lib/myfunc')
const chokidar = require('chokidar')

let session = `${sessionName}`
let pathz = './' + session
let usePairingCode = true
if (!fs.existsSync(pathz)) {
fs.mkdirSync(pathz, {
recursive: true
})
}

const storeFilePath = path.join(pathz, 'store.json')
if (!fs.existsSync(storeFilePath)) {
fs.writeFileSync(storeFilePath, JSON.stringify({
chats: [],
contacts: {},
messages: {},
presences: {}
}, null, 4))
}

const debounceWrite = (() => {
let timeout
return (callback) => {
clearTimeout(timeout)
timeout = setTimeout(() => callback(), 1000)
}
})()

const logger = {
trace: () => {},
debug: () => {},
info: () => {},
warn: () => {},
error: () => {},
fatal: () => {},
child: () => logger
}

const store = makeInMemoryStore({
logger
})

const initialData = JSON.parse(fs.readFileSync(storeFilePath, 'utf-8'))
store.chats = initialData.chats || []
store.contacts = initialData.contacts || {}
store.messages = initialData.messages || {}
store.presences = initialData.presences || {}
setInterval(() => {
debounceWrite(() => {
const formattedData = JSON.stringify({
chats: store.chats || [],
contacts: store.contacts || {},
messages: store.messages || {},
presences: store.presences || {}
}, null, 4)
fs.writeFileSync(storeFilePath, formattedData)
})
}, 10_000)

function saveData() {
fs.writeFileSync('./data/db/database.json', JSON.stringify(global.db, null, 2))
}

const question = (text) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); return new Promise((resolve) => { rl.question(text, resolve) }) };

function loadData() {
try {
const data = fs.readFileSync('./data/db/database.json')
return JSON.parse(data)
} catch (error) {
return {
data: {
users: {},
chats: {},
others: {},
settings: {}
}
}
}
}

global.db = loadData()
if (!global.db.data) global.db.data = {
users: {},
chats: {},
others: {},
settings: {}
}

if (!global.db.data.users) global.db.data.users = {}
saveData()
setInterval(saveData, 10000)

async function connectToWhatsApp() {
const {
state,
saveCreds
} = await useMultiFileAuthState(pathz)
const {
version,
isLatest
} = await fetchLatestBaileysVersion()
const conn = makeWASocket({
logger: logger,
printQRInTerminal: false,
auth: state,
version,
browser: Browsers.ubuntu("Firefox"),
generateHighQualityLinkPreview: false,
syncFullHistory: false,
markOnlineOnConnect: false,
emitOwnEvents: false
})
conn.ev.on('creds.update', saveCreds)
if (usePairingCode && !conn.authState.creds.registered) {
console.log("Proses memberi pairing code,,,,,");
const number = botNumber
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
await delay(6000);
const code = await conn.requestPairingCode(number, 'CAPEKCPK');
console.log(
chalk.black(chalk.bgGreen(`Your Pairing : `)),
chalk.black(chalk.white(code)),
);
}
store.bind(conn.ev)

const processedMessages = new Set()
conn.ev.on('messages.upsert', async (chatUpdate) => {
try {
const mek = chatUpdate.messages[0]
if (!mek.message) return
if (processedMessages.has(mek.key.id)) return
processedMessages.add(mek.key.id)
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast') return
const remoteJid = mek.key.remoteJid
const userId = mek.key.fromMe ? botNumber : mek.key.participant
const currentTimestamp = Date.now()
if (!store.presences) store.presences = {}
store.presences[userId] = {
lastOnline: currentTimestamp
}
if (!store.messages[remoteJid]) store.messages[remoteJid] = []
const simplifiedMessage = {
key: mek.key,
messageTimestamp: mek.messageTimestamp,
pushName: mek.pushName || null,
message: mek.message
}
store.messages[remoteJid].push(simplifiedMessage)
if (store.messages[remoteJid].length > 50) {
store.messages[remoteJid] = store.messages[remoteJid].slice(-50)
}
if (!store.chats.some(chat => chat.id === remoteJid)) {
store.chats.push({
id: remoteJid,
conversationTimestamp: mek.messageTimestamp || Date.now()
})
}
const m = smsg(conn, mek, store)
require('./anu')(conn, m, chatUpdate, store)
} catch (err) {
console.error(err)
}
})

conn.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

conn.ev.on('contacts.update', update => {
for (let contact of update) {
let id = conn.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = {
id,
name: contact.notify
}
}
})

conn.getName = (jid, withoutContact = false) => {
id = conn.decodeJid(jid)
withoutContact = conn.withoutContact || withoutContact
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = conn.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === conn.decodeJid(conn.user.id) ? conn.user : (store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}

conn.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await conn.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await conn.getName(i + '@s.whatsapp.net')}\nFN:${await conn.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:npofficiall@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:https://bit.ly/420u6GX\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
})
}
conn.sendMessage(jid, {
contacts: {
displayName: `${list.length} Kontak`,
contacts: list
},
...opts
}, {
quoted
})
}

conn.setStatus = (status) => {
conn.query({
tag: 'iq',
attrs: {
to: '@s.whatsapp.net',
type: 'set',
xmlns: 'status',
},
content: [{
tag: 'status',
attrs: {},
content: Buffer.from(status, 'utf-8')
}]
})
return status
}

conn.public = true
conn.serializeM = (m) => smsg(conn, m, store)

conn.getFile = async (PATH, returnAsFilename) => {
let res, filename
let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,` [1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await fetch(PATH)).buffer() : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
let type = await FileType.fromBuffer(data) || {
mime: 'application/octet-stream',
ext: '.bin'
}
if (data && returnAsFilename && !filename)(filename = path.join(__dirname, './' + new Date * 1 + '.' + type.ext), await fs.promises.writeFile(filename, data))
return {
res,
filename,
...type,
data
}
}

conn.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
let type = await conn.getFile(path, true)
let {
res,
data: file,
filename: pathFile
} = type
if (res && res.status !== 200 || file.length <= 65536) {
try {
throw {
json: JSON.parse(file.toString())
}
} catch (e) {
if (e.json) throw e.json
}
}
let opt = {
filename
}
if (quoted) opt.quoted = quoted
if (!type) options.asDocument = true
let mtype = '',
mimetype = type.mime,
convert
if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker'
else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image'
else if (/video/.test(type.mime)) mtype = 'video'
else if (/audio/.test(type.mime))(convert = await toAudio(file, type.ext), file = convert.data, pathFile = convert.filename, mtype = 'audio', mimetype = 'audio/ogg; codecs=opus')
else mtype = 'document'
if (options.asDocument) mtype = 'document'
delete options.asSticker
delete options.asLocation
delete options.asVideo
delete options.asDocument
delete options.asImage
let message = {
...options,
caption,
ptt,
[mtype]: {
url: pathFile
},
mimetype,
fileName: filename || pathFile.split('/').pop()
}
let m
try {
m = await conn.sendMessage(jid, message, {
...opt,
...options
})
} catch (e) {
m = null
} finally {
if (!m) m = await conn.sendMessage(jid, {
...message,
[mtype]: file
}, {
...opt,
...options
})
file = null
return m
}
}

conn.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
let mime = ''
let res = await axios.head(url)
mime = res.headers['content-type']
if (mime.split("/")[1] === "gif") {
return conn.sendMessage(jid, {
video: await getBuffer(url),
caption: caption,
gifPlayback: true,
...options
}, {
quoted: quoted,
...options
})
}
let type = mime.split("/")[0] + "Message"
if (mime === "application/pdf") {
return conn.sendMessage(jid, {
document: await getBuffer(url),
mimetype: 'application/pdf',
caption: caption,
...options
}, {
quoted: quoted,
...options
})
}
if (mime.split("/")[0] === "image") {
return conn.sendMessage(jid, {
image: await getBuffer(url),
caption: caption,
...options
}, {
quoted: quoted,
...options
})
}
if (mime.split("/")[0] === "video") {
return conn.sendMessage(jid, {
video: await getBuffer(url),
caption: caption,
mimetype: 'video/mp4',
...options
}, {
quoted: quoted,
...options
})
}
if (mime.split("/")[0] === "audio") {
return conn.sendMessage(jid, {
audio: await getBuffer(url),
caption: caption,
mimetype: 'audio/mpeg',
...options
}, {
quoted: quoted,
...options
})
}
}

conn.sendTextWithMentions = async (jid, text, quoted, options = {}) => conn.sendMessage(jid, {
text: text,
mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
...options
}, {
quoted
})

conn.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await conn.sendMessage(jid, {
image: buffer,
caption: caption,
...options
}, {
quoted
})
}

conn.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await (const chunk of stream) {
buffer = Buffer.concat([
buffer, chunk
])
}
let type = await FileType.fromBuffer(buffer)
let trueFileName = attachExtension ? ('./lib/' + filename + '.' + type.ext) : './lib/' + filename
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}
conn.sendStickerFromUrl = async (from, PATH, quoted, options = {}) => {
let {
writeExif
} = require('./lib/sticker')
let types = await conn.getFile(PATH, true)
let {
filename,
size,
ext,
mime,
data
} = types
let type = '',
mimetype = mime,
pathFile = filename
let media = {
mimetype: mime,
data
}
pathFile = await writeExif(media, {
packname: options.packname ? options.packname : '',
author: options.author ? options.author : author,
categories: options.categories ? options.categories : []
})
await fs.promises.unlink(filename)
await conn.sendMessage(from, {
sticker: {
url: pathFile
}
}, {
quoted
})
return fs.promises.unlink(pathFile)
}

conn.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await (const chunk of stream) {
buffer = Buffer.concat([
buffer, chunk
])
}
return buffer
}

conn.sendAudio = async (jid, path, quoted = '', ptt = false, options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await conn.sendMessage(jid, {
audio: buffer,
ptt: ptt,
...options
}, {
quoted
})
}

conn.sendVideo = async (jid, path, gif = false, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await conn.sendMessage(jid, {
video: buffer,
caption: caption,
gifPlayback: gif,
...options
}, {
quoted
})
}

conn.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await global.getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await conn.sendMessage(jid, {
sticker: {
url: buffer
},
...options
}, {
quoted
})
return buffer
}

conn.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await global.getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)
}
await conn.sendMessage(jid, {
sticker: {
url: buffer
},
...options
}, {
quoted
})
return buffer
}

conn.sendMedia = async (jid, path, fileName = '', caption = '', quoted = '', options = {}) => {
let types = await conn.getFile(path, true)
let {
mime,
ext,
res,
data,
filename
} = types
if (res && res.status !== 200 || file.length <= 65536) {
try {
throw {
json: JSON.parse(file.toString())
}
} catch (e) {
if (e.json) throw e.json
}
}
let type = '',
mimetype = mime,
pathFile = filename
if (options.asDocument) type = 'document'
if (options.asSticker || /webp/.test(mime)) {
let media = {
mimetype: mime,
data
}
pathFile = await writeExif(media, {
packname: options.packname ? options.packname : global.packname,
author: options.author ? options.author : global.author,
categories: options.categories ? options.categories : []
})
await fs.promises.unlink(filename)
type = 'sticker'
mimetype = 'image/webp'
} else if (/image/.test(mime)) type = 'image'
else if (/video/.test(mime)) type = 'video'
else if (/audio/.test(mime)) type = 'audio'
else type = 'document'
await conn.sendMessage(jid, {
[type]: {
url: pathFile
},
caption,
mimetype,
fileName,
...options
}, {
quoted,
...options
})
return fs.promises.unlink(pathFile)
}

conn.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readViewOnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message
}
}
let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
content[ctype].contextInfo = {
...context,
...content[ctype].contextInfo
}
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
...content[ctype],
...options,
...(options.contextInfo ? {
contextInfo: {
...content[ctype].contextInfo,
...options.contextInfo
}
} : {})
} : {})
await conn.relayMessage(jid, waMessage.message, {
messageId: waMessage.key.id
})
return waMessage
}

conn.imgToSticker = async (from, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetchBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await conn.sendMessage(from, {
sticker: {
url: buffer
},
...options
}, {
quoted
})
return buffer
}

conn.vidToSticker = async (from, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await fetchBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)
}
await conn.sendMessage(from, {
sticker: {
url: buffer
},
...options
}, {
quoted
})
return buffer
}

conn.sendText = (jid, text, quoted = '', options) => conn.sendMessage(jid, {
text: text,
...options
}, {
quoted,
...options
})

conn.cMod = (jid, copy, text = '', sender = conn.user.id, options = {}) => {
//let copy = message.toJSON()
let mtype = Object.keys(copy.message)[0]
let isEphemeral = mtype === 'ephemeralMessage'
if (isEphemeral) {
mtype = Object.keys(copy.message.ephemeralMessage.message)[0]
}
let msg = isEphemeral ? copy.message.ephemeralMessage.message : copy.message
let content = msg[mtype]
if (typeof content === 'string') msg[mtype] = text || content
else if (content.caption) content.caption = text || content.caption
else if (content.text) content.text = text || content.text
if (typeof content !== 'string') msg[mtype] = {
...content,
...options
}
if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
else if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
if (copy.key.remoteJid.includes('@s.whatsapp.net')) sender = sender || copy.key.remoteJid
else if (copy.key.remoteJid.includes('@broadcast')) sender = sender || copy.key.remoteJid
copy.key.remoteJid = jid
copy.key.fromMe = sender === conn.user.id
return proto.WebMessageInfo.fromObject(copy)
}

conn.ev.on("connection.update", async (update) => {
const {
connection,
lastDisconnect
} = update
if (connection === "close") {
let reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.statusCode
if (reason === DisconnectReason.badSession) {
console.log(`Session error, please delete the session and try again...`)
process.exit()
} else if (reason === DisconnectReason.connectionClosed) {
console.log('Connection closed, reconnecting....')
connectToWhatsApp()
} else if (reason === DisconnectReason.connectionLost) {
console.log('Connection lost from the server, reconnecting...')
connectToWhatsApp()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log('Session connected to another server, please restart the bot.');
process.exit()
} else if (reason === DisconnectReason.loggedOut) {
console.log(`Device logged out, please delete the session folder and scan again.`)
process.exit()
} else if (reason === DisconnectReason.restartRequired) {
console.log('Restart required, restarting connection...')
connectToWhatsApp()
} else if (reason === DisconnectReason.timedOut) {
console.log('Connection timed out, reconnecting...')
connectToWhatsApp()
} else {
console.log(`Unknown DisconnectReason: ${reason}|${connection}`)
connectToWhatsApp()
}
} else if (connection === "connecting") {
console.log('')
} else if (connection === "open") {
console.log(chalk.green.bold('\nBot berhasil terkoneksi...'))
}
})

return conn
}

connectToWhatsApp()
process.on("uncaughtException", (error) => {
console.log(error)
})

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)})