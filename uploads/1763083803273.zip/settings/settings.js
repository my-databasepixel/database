const fs = require('fs')

// Bot Settings
global.storename = "Ikann"
global.botname = "IkannNew"
global.ownername = "Ikann"
global.owner = "6285187440738"
global.versi = "1.9"
global.sessionName = "ikannses"
global.botNumber = "6285187440738"
global.author = "Sticker"
global.wm = "ikann-2025"

global.prefixx = false
global.github = {
    username: "ShotaQuen",
    repo: "databseStore",
    db: "database.json",
    list: "list.json",
    token: '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'
};

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)})