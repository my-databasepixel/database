process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings/settings')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, useMultiFileAuthState, makeWASocket, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, makeWaSocket } = require("@whiskeysockets/baileys")

const fs = require("fs");
const path = require("path");
const { GoogleGenerativeAI } = require("@google/generative-ai")
const util = require('util');
const axios = require('axios');
const chalk = require('chalk');
const moment = require("moment-timezone");
const ms = require('parse-ms')
const nou = require("node-os-utils");
const os = require('os');
const FormData = require('form-data');
const didyoumean = require('didyoumean');
const ffmpeg = require('fluent-ffmpeg')

const { exec, execSync } = require('child_process')

//==========================
const own = JSON.parse(fs.readFileSync('./data/owner.json').toString())

module.exports = conn = async (conn, m, chatUpdate, mek, store) => {
try {

const chalk = require('chalk')
const { type } = m

var body = m.body
var budy = m.text
const prefix = /^[.]/.test(body) ? body.match(/^[.]/gi) : '.'
const isCmd = body.startsWith(prefix)
const ico = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ''
const icoo = body.replace(/^[!#.]/, '').trim().split(/ +/).shift().toLowerCase()
const command = prefixx ? ico : icoo
const pushname = m.pushName || "No Name"
const botNumber = await conn.decodeJid(conn.user.id)
const bulan = moment.tz('Asia/Jakarta').format('DD MMMM')
const bulan2 = moment.tz('Asia/Jakarta').format('MMMM')
const bulan3 = moment.tz('Asia/Jakarta').format('DD')
const tahun = moment.tz('Asia/Jakarta').format('YYYY')
const tanggal = moment().tz("Asia/Jakarta").format("dddd, d")
const tanggall = moment().tz("Asia/Jakarta").format("d")
const testiDate = `${tanggal}-${bulan}-${tahun}`
const testiDateText = `${tanggall}-${bulan2}-${tahun}`
const jam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss')
const wibTime = moment().tz('Asia/Jakarta').format('HH:mm:ss')
const penghitung = moment().tz("Asia/Jakarta").format("dddd, D MMMM - YYYY")
const tglini = new Date().toLocaleString();
// Fungsi bantu untuk mengubah list ke array JID
const toJids = (list = []) => {
return list
.filter(v => typeof v === 'string' && v.trim() !== '')
.map(v => v.replace(/[^0-9]/g, '')) // ambil angka saja
.flatMap(v => [`${v}@s.whatsapp.net`, `${v}@lid`]); // hasilkan dua format
}

const ownerJids = toJids([owner, botNumber, ...own]);

let isOwner = false;
if (m.isGroup) {
if (!m.metadata) {
m.metadata = await conn.groupMetadata(m.chat).catch(() => ({}));
}
const participants = m.metadata?.participants || [];
let senderLid = participants.find(p => {
const jid = (p.jid || '').toLowerCase();
const lid = (p.lid || '').toLowerCase();
const sender = (m.sender || '').toLowerCase();
return jid === sender || lid === sender;
})?.lid;
if (!senderLid) senderLid = (m.sender || '').toLowerCase();
isOwner = ownerJids.includes(senderLid);
} else {
isOwner = ownerJids.includes((m.sender || '').toLowerCase());
}
let senderLidCheck;
if (m.isGroup) {
if (!m.metadata) {
m.metadata = await conn.groupMetadata(m.chat).catch(() => ({}));
}
const participants = m.metadata?.participants || [];
senderLidCheck = participants.find(p => {
const jid = (p.jid || '').toLowerCase();
const lid = (p.lid || '').toLowerCase();
const sender = (m.sender || '').toLowerCase();
return jid === sender || lid === sender;
})?.lid;
}
if (!senderLidCheck) senderLidCheck = (m.sender || '').toLowerCase();

if (budy.startsWith('=> ')) {
if (!m.fromMe && !isOwner) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)
}
return m.reply(bang)
}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(util.format(e))
}}

if (budy.startsWith('> ')) {
if (!m.fromMe && !isOwner) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(util.format(err))
}}

if (budy.startsWith('$ ')) {
if (!m.fromMe && !isOwner) return 
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})}

const args = body.trim().split(/ +/).slice(1)
const full_args = body.replace(command, '').slice(1).trim()
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = m.key.remoteJid
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const isMediaa = /image|video/.test(mime)
const isPc = from.endsWith('@s.whatsapp.net')
const isGc = from.endsWith('@g.us')
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const qmsg = (quoted.msg || quoted)
const sender = m.key.fromMe ? (conn.user.id.split(':')[0]+'@s.whatsapp.net' || conn.user.id) : (m.key.participant || m.key.remoteJid)
const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : {};
const participants = m.isGroup ? groupMetadata.participants || [] : [];
const groupAdmins = m.isGroup
? participants.filter(p => p.admin !== null && p.admin !== undefined).map(p => p.id)
: [];
const groupOwner = m.isGroup ? groupMetadata.owner || null : null;
let isBotAdmins = false;

if (m.isGroup) {
if (!m.metadata) {
m.metadata = await conn.groupMetadata(m.chat).catch(() => ({}));
}

const participants = m.metadata?.participants || [];

const adminLids = participants
.filter(p => {
const admin = (p.admin || '').toLowerCase();
return admin === 'admin' || admin === 'superadmin' || p.isAdmin === true;
})
.map(p => (p.lid || '').toLowerCase());
const botJid = (botNumber || '').toLowerCase();
let botLid = participants.find(p => {
const jid = (p.jid || '').toLowerCase();
const lid = (p.lid || '').toLowerCase();
return jid === botJid || lid === botJid;
})?.lid;

if (!botLid) botLid = botJid;

isBotAdmins = adminLids.includes(botLid);
}
let isAdmins = false;

if (m.isGroup) {
if (!m.metadata) {
m.metadata = await conn.groupMetadata(m.chat).catch(() => ({}));
}

const participants = m.metadata?.participants || [];

const adminLids = participants
.filter(p => {
const admin = (p.admin || '').toLowerCase();
return admin === 'admin' || admin === 'superadmin' || p.isAdmin === true;
})
.map(p => (p.lid || '').toLowerCase());

let senderLid = participants.find(p => {
const jid = (p.jid || '').toLowerCase();
const lid = (p.lid || '').toLowerCase();
const sender = (m.sender || '').toLowerCase();
return jid === sender || lid === sender;
})?.lid;

if (!senderLid) senderLid = (m.sender || '').toLowerCase();

isAdmins = adminLids.includes(senderLid);
}
const groupMembers = m.isGroup ? groupMetadata.participants : ''
const isGroup = m.isGroup
const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
const tag = `${m.sender.split('@')[0]}`
const tagg = `${m.sender.split('@')[0]}`+'@s.whatsapp.net'
const isImage = (type == 'imageMessage')
const isVideo = (type == 'videoMessage')
const isAudio = (type == 'audioMessage')
const isSticker = (type == 'stickerMessage')
const m2 = '`'
const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `connNew`,jpegThumbnail: ""}}}
const _p = prefix
const p_c = prefix+command
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

if (!conn.public) {
if (!isOwner && !m.key.fromMe) return
}

async function react() {
await conn.sendMessage(from, { react: { text: '⏳', key: m.key }})
}

const ftext = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: {extendedTextMessage: {text: `${command} ${text}`}}}
conn.ments = (teks = '') => {
return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []}
conn.sendTeks = async(chatId, text = '', quoted = '', opts = {}) => {
return conn.sendMessage(chatId, { text: text, mentions: await conn.ments(text), ...opts}, {quoted: quoted})}
conn.sendPoll = (jid, name = '', values = [], selectableCount = global.select) => {
return conn.sendMessage(jid, {poll: { name, values, selectableCount }})}
const reply = (teks) => {
return conn.sendMessage(m.chat, { text: teks, mentions: conn.ments(teks) }, {quoted: m})
}

switch (command) {

default:

}
} catch (err) {
console.log(util.format(err))
let e = String(err)

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)})