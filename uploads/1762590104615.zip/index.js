const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const input = require('input');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

let handleCommand = require('./case');

// 🔁 Auto-reload case.js on file change
const casePath = path.resolve('./case.js');
fs.watchFile(casePath, () => {
  try {
    delete require.cache[require.resolve('./case')];
    handleCommand = require('./case');
    console.log(chalk.yellowBright('♻️ Commands reloaded from case.js'));
  } catch (err) {
    console.error(chalk.red('❌ Failed to reload case.js:'), err);
  }
});

// ─────────────────────────────
// Telegram client configuration
// ─────────────────────────────
const apiId = parseInt(process.env.API_ID || '123456');
const apiHash = process.env.API_HASH || 'your_api_hash_here';
const sessionString =
  process.env.STRING_SESSION ||
  (fs.existsSync('./string.txt') ? fs.readFileSync('./string.txt', 'utf8').trim() : '');
const stringSession = new StringSession(sessionString);

(async () => {
  console.log(chalk.cyanBright('🚀 Starting Trashcore UserBot...'));

  const client = new TelegramClient(stringSession, apiId, apiHash, {
    connectionRetries: 5,
  });

  // ──────────── LOGIN ─────────────
  if (!sessionString) {
    try {
      await client.start({
        phoneNumber: async () => await input.text('📱 Enter your phone number: '),
        phoneCode: async () => await input.text('💬 Enter the code you received: '),
        password: async () => {
          const pass = await input.text('🔒 Enter your 2FA password (leave empty if none): ');
          return pass.trim() === '' ? undefined : pass;
        },
        onError: (err) => console.error('Login error:', err),
      });

      const saved = client.session.save();
      fs.writeFileSync('string.txt', saved);
      console.log(chalk.green('\n✅ Login successful! Session saved to string.txt'));
    } catch (err) {
      console.error(chalk.red('❌ Login failed:'), err);
      process.exit(1);
    }
  } else {
    await client.connect();
    console.log(chalk.green('✅ Connected using saved session.'));
  }

  const me = await client.getMe();
  console.log(chalk.blueBright(`🤖 Logged in as: ${me.username || me.firstName}`));

  // ──────────── MESSAGE HANDLER ─────────────
  client.addEventHandler(async (event) => {
    if (!event.message || !event.message.message) return;

    const msg = event.message.message.trim();
    const sender = await event.message.getSender();
    const chat = await event.message.getChat();

    // 🧾 Display colorized message in console
    const chatName = chat?.title ? chalk.cyanBright(`🌐 ${chat.title}`) : chalk.green(`👤 ${sender?.username || sender?.firstName}`);
    const senderId = chalk.gray(`(${sender?.id})`);
    const messageText = chalk.white(msg);

    console.log(`💬 ${chatName} ${senderId} → ${messageText}`);

    // Ignore messages without command prefix
    if (!msg.startsWith('.')) return;

    const args = msg.slice(1).split(/\s+/);
    const command = args.shift().toLowerCase();
    const inputText = args.join(' ');

    try {
      await handleCommand(client, event, command, inputText);
    } catch (err) {
      console.error(chalk.red('⚠️ Command error:'), err);
      await event.respond('❌ An error occurred while processing your command.');
    }
  });
})();