const os = require('os');
const process = require('process');
const packageJson = require('./package.json'); // Import version dynamically

const startTime = Date.now(); // Track bot uptime

module.exports = async function handleCommand(client, event, command, text) {
  switch (command) {
    case 'ping': {
      const start = Date.now();
      await event.respond('🏓 Pinging...');
      const ms = Date.now() - start;
      await event.edit(`✅ Pong! ${ms}ms`);
      break;
    }

    case 'echo': {
      if (!text) return await event.respond('🗣️ Usage: .echo <text>');
      await event.respond(text);
      break;
    }

    case 'info': {
      const me = await client.getMe();
      await event.respond(
        `👤 USER INFO
ID: ${me.id}
Name: ${me.firstName}
Username: @${me.username || 'N/A'}`
      );
      break;
    }

    case 'help':
    case 'menu': {
      const imageUrl = 'https://files.catbox.moe/2wj395.jpg'; // Replace with your own image

      // 🕒 Calculate uptime
      const uptimeMs = Date.now() - startTime;
      const seconds = Math.floor((uptimeMs / 1000) % 60);
      const minutes = Math.floor((uptimeMs / (1000 * 60)) % 60);
      const hours = Math.floor((uptimeMs / (1000 * 60 * 60)) % 24);
      const days = Math.floor(uptimeMs / (1000 * 60 * 60 * 24));
      const uptime = `${days}d ${hours}h ${minutes}m ${seconds}s`;

      const caption = `
╭─────────────╮
🤖  TRASHCORE USERBOT MENU
╰─────────────╯

👑 Creator: Trashcore
🧩 Version: ${packageJson.version}
⏱️ Uptime: ${uptime}
💻 Language: JavaScript
🖥️ OS: ${os.type()} ${os.arch()}

⚙️ GENERAL COMMANDS:
• .ping 
• .echo 
• .info
• .menu 

🧠 PREFIX: .
───────────────────
Trashcore UserBot — Power & Simplicity ⚡
`;

      try {
        await client.sendFile(event.chatId, { file: imageUrl, caption });
      } catch (err) {
        console.error('❌ Failed to send menu image:', err);
        await event.respond(caption);
      }
      break;
    }

    default:
      await event.respond(`❓ Unknown command: ${command}\nType .menu to view all commands.`);
  }
};